This is the official source code repository for **UCanAccess**, a pure Java JDBC driver for working with
Microsoft Access database files.

If you want to download the latest release, you can do that [here](https://sourceforge.net/projects/ucanaccess/files/latest/download).

For more information on how to use UCanAccess, see the [web site](http://ucanaccess.sourceforge.net/site.html).

---

UCanAccess is licensed under the [Apache License, Version 2.0](http://www.apache.org/licenses/LICENSE-2.0).